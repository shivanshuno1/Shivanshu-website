import React from 'react';
import SectionReveal from './SectionReveal';
import Logo from './Logo';
import { profile, education } from '../data/resumeData';

export default function About() {
  return (
    <section id="about" className="max-w-6xl mx-auto px-6 py-28">
      <SectionReveal>
        <span className="font-mono text-xs uppercase tracking-[0.3em] text-cyan">01 / About</span>
      </SectionReveal>
      <SectionReveal delay={0.1} className="mt-6">
        <p className="font-display text-2xl md:text-4xl leading-snug text-mist max-w-3xl">
          {profile.summary}
        </p>
      </SectionReveal>
      <SectionReveal delay={0.2} className="mt-10 flex flex-col sm:flex-row gap-6 sm:gap-16 border-t border-white/10 pt-8">
        <div className="flex items-start gap-4">
          <Logo name={education.logoKey} size="md" className="mt-1 shrink-0" />
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-haze mb-2">Education</p>
            <p className="text-mist font-medium">{education.degree}</p>
            <p className="text-haze text-sm mt-1">{education.school}</p>
          </div>
        </div>
        <div>
          <p className="font-mono text-xs uppercase tracking-widest text-haze mb-2">Based in</p>
          <p className="text-mist font-medium">{profile.location}</p>
        </div>
      </SectionReveal>
    </section>
  );
}
