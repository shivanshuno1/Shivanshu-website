import React, { useMemo, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, Stars, MeshDistortMaterial, Icosahedron, Line } from '@react-three/drei';
import * as THREE from 'three';

// A ring of nodes orbiting the central core, connected by faint lines —
// a stand-in "knowledge graph" linking data science + full-stack skills.
function NodeNetwork() {
  const group = useRef();
  const nodeCount = 18;

  const nodes = useMemo(() => {
    const pts = [];
    for (let i = 0; i < nodeCount; i++) {
      const phi = Math.acos(-1 + (2 * i) / nodeCount);
      const theta = Math.sqrt(nodeCount * Math.PI) * phi;
      const radius = 3.4;
      pts.push(
        new THREE.Vector3(
          radius * Math.cos(theta) * Math.sin(phi),
          radius * Math.sin(theta) * Math.sin(phi),
          radius * Math.cos(phi)
        )
      );
    }
    return pts;
  }, []);

  const lines = useMemo(() => {
    const segs = [];
    for (let i = 0; i < nodes.length; i++) {
      const next = nodes[(i + 3) % nodes.length];
      segs.push([nodes[i], next]);
    }
    return segs;
  }, [nodes]);

  useFrame((state, delta) => {
    if (group.current) {
      group.current.rotation.y += delta * 0.08;
      group.current.rotation.x += delta * 0.02;
    }
  });

  return (
    <group ref={group}>
      {nodes.map((p, i) => (
        <mesh key={i} position={p}>
          <sphereGeometry args={[0.045, 12, 12]} />
          <meshStandardMaterial
            color={i % 3 === 0 ? '#4FF3D0' : '#8B7CF6'}
            emissive={i % 3 === 0 ? '#4FF3D0' : '#8B7CF6'}
            emissiveIntensity={1.4}
          />
        </mesh>
      ))}
      {lines.map((pair, i) => (
        <Line key={i} points={pair} color="#4FF3D0" transparent opacity={0.18} lineWidth={1} />
      ))}
    </group>
  );
}

function Core() {
  const meshRef = useRef();
  useFrame((state, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += delta * 0.15;
      meshRef.current.rotation.z += delta * 0.05;
    }
  });
  return (
    <Float speed={1.4} rotationIntensity={0.6} floatIntensity={0.8}>
      <Icosahedron ref={meshRef} args={[1.35, 2]}>
        <MeshDistortMaterial
          color="#0B0E16"
          emissive="#4FF3D0"
          emissiveIntensity={0.25}
          roughness={0.15}
          metalness={0.6}
          distort={0.35}
          speed={1.6}
          wireframe
        />
      </Icosahedron>
    </Float>
  );
}

function Rig() {
  // Subtle camera parallax that follows the pointer.
  useFrame((state) => {
    const { pointer, camera } = state;
    camera.position.x += (pointer.x * 0.6 - camera.position.x) * 0.02;
    camera.position.y += (pointer.y * 0.4 - camera.position.y) * 0.02;
    camera.lookAt(0, 0, 0);
  });
  return null;
}

export default function Hero3D() {
  return (
    <Canvas
      camera={{ position: [0, 0, 7.5], fov: 45 }}
      dpr={[1, 1.75]}
      gl={{ antialias: true, alpha: true }}
    >
      <ambientLight intensity={0.5} />
      <pointLight position={[5, 5, 5]} intensity={1.2} color="#4FF3D0" />
      <pointLight position={[-5, -3, -5]} intensity={0.8} color="#8B7CF6" />
      <Stars radius={60} depth={40} count={2200} factor={2.2} saturation={0} fade speed={0.6} />
      <Core />
      <NodeNetwork />
      <Rig />
    </Canvas>
  );
}
